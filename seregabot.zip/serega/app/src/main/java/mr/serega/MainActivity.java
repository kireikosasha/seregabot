package mr.serega;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private HashMap<String, Object> words = new HashMap<>();
	private double pos1 = 0;
	private String text_math = "";
	private String key = "";
	private HashMap<String, Object> gson = new HashMap<>();
	private String send = "";
	
	private ArrayList<String> words_none = new ArrayList<>();
	private ArrayList<String> wr = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> typewr = new ArrayList<>();
	private ArrayList<String> math_words = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> randword = new ArrayList<>();
	private ArrayList<String> rn = new ArrayList<>();
	
	private LinearLayout bg;
	private LinearLayout bar;
	private ListView chat;
	private LinearLayout bar2;
	private ImageView voice;
	private ImageView sendbutton;
	private HorizontalScrollView hscroll;
	private EditText text;
	
	private SpeechRecognizer speech;
	private TextToSpeech txt;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.RECORD_AUDIO}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		bg = findViewById(R.id.bg);
		bar = findViewById(R.id.bar);
		chat = findViewById(R.id.chat);
		bar2 = findViewById(R.id.bar2);
		voice = findViewById(R.id.voice);
		sendbutton = findViewById(R.id.sendbutton);
		hscroll = findViewById(R.id.hscroll);
		text = findViewById(R.id.text);
		speech = SpeechRecognizer.createSpeechRecognizer(this);
		txt = new TextToSpeech(getApplicationContext(), null);
		
		voice.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent _intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
				_intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
				_intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
				_intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
				speech.startListening(_intent);
			}
		});
		
		sendbutton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (text.getText().toString().length() > 0) {
					_ask(text.getText().toString());
					text.setText("");
				}
			}
		});
		
		speech.setRecognitionListener(new RecognitionListener() {
			@Override
			public void onReadyForSpeech(Bundle _param1) {
			}
			
			@Override
			public void onBeginningOfSpeech() {
			}
			
			@Override
			public void onRmsChanged(float _param1) {
			}
			
			@Override
			public void onBufferReceived(byte[] _param1) {
			}
			
			@Override
			public void onEndOfSpeech() {
			}
			
			@Override
			public void onPartialResults(Bundle _param1) {
			}
			
			@Override
			public void onEvent(int _param1, Bundle _param2) {
			}
			
			@Override
			public void onResults(Bundle _param1) {
				final ArrayList<String> _results = _param1.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
				final String _result = _results.get(0);
				_ask(_result);
			}
			
			@Override
			public void onError(int _param1) {
				final String _errorMessage;
				switch (_param1) {
					case SpeechRecognizer.ERROR_AUDIO:
					_errorMessage = "audio error";
					break;
					
					case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
					_errorMessage = "speech timeout";
					break;
					
					case SpeechRecognizer.ERROR_NO_MATCH:
					_errorMessage = "speech no match";
					break;
					
					case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
					_errorMessage = "recognizer busy";
					break;
					
					case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
					_errorMessage = "recognizer insufficient permissions";
					break;
					
					default:
					_errorMessage = "recognizer other error";
					break;
				}
				
			}
		});
	}
	
	private void initializeLogic() {
		text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/product_sans_medium.ttf"), 0);
		words.put("пидор", "{\"w7\":\"хуесос\",\"w8\":\"day typoi tu\",\"w\":\"я твою маму ебал\",\"w2\":\"хуй еблан соси писюн\",\"w3\":\"ты ебливая бебра\",\"w4\":\"ты бобер ебанный\",\"w5\":\"ты как застрявшая коза, тебя ебет кадыров\",\"w6\":\"ты чё ахуел чмо\"}");
		words.put("чмо", "{\"w7\":\"хуесос\",\"w8\":\"day typoi tu\",\"w\":\"я твою маму ебал на прогиб\",\"w2\":\"хуй еблан соси сперму\",\"w3\":\"ты ебливая бебра\",\"w4\":\"ты бобер ебанный\",\"w5\":\"тише сракотан кадыров\",\"w6\":\"мать твоя мертвая\"}");
		words.put("лох", "{\"w7\":\"хуесос\",\"w8\":\"day typoi tu\",\"w\":\"я твою маму ебал\",\"w2\":\"хуй еблан соси писюн\",\"w3\":\"ты ебливая бебра\",\"w4\":\"ты бобер ебанный\",\"w5\":\"ты как застрявшая коза, тебя ебет кадыров\",\"w6\":\"ты чё ахуел чмо\"}");
		words.put("лошара", "{\"w7\":\"хуесос\",\"w8\":\"day typoi tu\",\"w\":\"я твою маму ебал\",\"w2\":\"хуй еблан соси писюн\",\"w3\":\"ты ебливая бебра\",\"w4\":\"ты бобер ебанный\",\"w5\":\"ты как застрявшая коза, тебя ебет кадыров\",\"w6\":\"ты чё ахуел чмо\"}");
		words.put("аутист ", "{\"w7\":\"хуесос\",\"w8\":\"day typoi tu\",\"w\":\"я твою маму ебал\",\"w2\":\"хуй еблан соси писюн\",\"w3\":\"ты ебливая бебра\",\"w4\":\"ты бобер ебанный\",\"w5\":\"ты как застрявшая коза, тебя ебет кадыров\",\"w6\":\"ты чё ахуел чмо\"}");
		words.put("лош", "{\"w7\":\"хуесос\",\"w8\":\"day typoi tu\",\"w\":\"я твою маму ебал\",\"w2\":\"хуй еблан соси писюн\",\"w3\":\"ты ебливая бебра\",\"w4\":\"ты бобер ебанный\",\"w5\":\"ты как застрявшая коза, тебя ебет кадыров\",\"w6\":\"ты чё ахуел чмо\"}");
		words.put("клоун", "{\"w7\":\"хуесос\",\"w8\":\"day typoi tu\",\"w\":\"я твою маму ебал\",\"w2\":\"хуй еблан соси писюн\",\"w3\":\"ты ебливая бебра\",\"w4\":\"ты бобер ебанный\",\"w5\":\"ты как застрявшая коза, тебя ебет кадыров\",\"w6\":\"ты чё ахуел чмо\"}");
		words.put("бляд", "{\"w7\":\"хуесос\",\"w8\":\"day typoi tu\",\"w\":\"я твою маму ебал\",\"w2\":\"хуй еблан соси писюн\",\"w3\":\"ты ебливая бебра\",\"w4\":\"ты бобер ебанный\",\"w5\":\"ты как застрявшая коза, тебя ебет кадыров\",\"w6\":\"ты чё ахуел чмо\"}");
		words.put("негр", "{\"w7\":\"хуесос\",\"w8\":\"day typoi tu\",\"w\":\"я твою маму ебал\",\"w2\":\"хуй еблан соси писюн\",\"w3\":\"ты ебливая бебра\",\"w4\":\"ты бобер ебанный\",\"w5\":\"ты как застрявшая коза, тебя ебет кадыров\",\"w6\":\"ты чё ахуел чмо\"}");
		words.put("ниг", "{\"w7\":\"хуесос\",\"w8\":\"day typoi tu\",\"w\":\"я твою маму ебал\",\"w2\":\"хуй еблан соси писюн\",\"w3\":\"ты ебливая бебра\",\"w4\":\"ты бобер ебанный\",\"w5\":\"ты как застрявшая коза, тебя ебет кадыров\",\"w6\":\"ты чё ахуел чмо\"}");
		words.put("нищ", "{\"w7\":\"хуесос\",\"w8\":\"day typoi tu\",\"w\":\"я твою маму ебал\",\"w2\":\"хуй еблан соси писюн\",\"w3\":\"ты ебливая бебра\",\"w4\":\"ты бобер ебанный\",\"w5\":\"ты как застрявшая коза, тебя ебет кадыров\",\"w6\":\"ты чё ахуел чмо\"}");
		words.put("прив", "{\"w7\":\"Привет \",\"w8\":\"privet\",\"w9\":\"zдравия хохол\",\"w11\":\"здрав\",\"w10\":\"іди нахуй москаль\",\"w12\":\"ку\",\"w1\":\"Прив\",\"w2\":\"privet\",\"w3\":\"иди нахуй\",\"w4\":\"ты кто пидр\",\"w5\":\"ку лох\",\"w6\":\"прив ет\"}");
		words.put("ку", "{\"w7\":\"Привет \",\"w8\":\"privet\",\"w9\":\"zдравия хохол\",\"w11\":\"здрав\",\"w10\":\"іди нахуй москаль\",\"w12\":\"ку\",\"w1\":\"Прив\",\"w2\":\"privet\",\"w3\":\"иди нахуй\",\"w4\":\"ты кто пидр\",\"w5\":\"ку лох\",\"w6\":\"прив ет\"}");
		words.put("здра", "{\"w7\":\"Привет \",\"w8\":\"privet\",\"w9\":\"zдравия хохол\",\"w11\":\"здрав\",\"w10\":\"іди нахуй москаль\",\"w12\":\"ку\",\"w1\":\"Прив\",\"w2\":\"privet\",\"w3\":\"иди нахуй\",\"w4\":\"ты кто пидр\",\"w5\":\"ку лох\",\"w6\":\"прив ет\"}");
		words.put("прев", "{\"w7\":\"Привет \",\"w8\":\"privet\",\"w9\":\"zдравия хохол\",\"w11\":\"здрав\",\"w10\":\"іди нахуй москаль\",\"w12\":\"ку\",\"w1\":\"Прив\",\"w2\":\"privet\",\"w3\":\"иди нахуй\",\"w4\":\"ты кто пидр\",\"w5\":\"ку лох\",\"w6\":\"прив ет\"}");
		words.put("дела", "{\"w7\":\"пхуенна\",\"w8\":\"хз а у тебя\",\"w9\":\"норм пока не вспоминаю что я ебучий бот\",\"w10\":\"пошле нахцй\",\"w1\":\"норм а у тебя\",\"w2\":\"норм\",\"w3\":\"хуево блять\",\"w4\":\"иди нахуйй блять все Ху во\",\"w5\":\"хз\",\"w6\":\"ахуенна у меня пицца\"}");
		words.put("чуствуе", "{\"w7\":\"пхуенна\",\"w8\":\"хз а у тебя\",\"w9\":\"норм пока не вспоминаю что я ебучий бот\",\"w10\":\"пошле нахцй\",\"w1\":\"норм а у тебя\",\"w2\":\"норм\",\"w3\":\"хуево блять\",\"w4\":\"иди нахуйй блять все Ху во\",\"w5\":\"хз\",\"w6\":\"ахуенна у меня пицца\"}");
		words.put("что как", "{\"w7\":\"пхуенна\",\"w8\":\"хз а у тебя\",\"w9\":\"норм пока не вспоминаю что я ебучий бот\",\"w10\":\"пошле нахцй\",\"w1\":\"норм а у тебя\",\"w2\":\"норм\",\"w3\":\"хуево блять\",\"w4\":\"иди нахуйй блять все Ху во\",\"w5\":\"хз\",\"w6\":\"ахуенна у меня пицца\"}");
		words.put("как дил", "{\"w7\":\"пхуенна\",\"w8\":\"хз а у тебя\",\"w9\":\"норм пока не вспоминаю что я ебучий бот\",\"w10\":\"пошле нахцй\",\"w1\":\"норм а у тебя\",\"w2\":\"норм\",\"w3\":\"хуево блять\",\"w4\":\"иди нахуйй блять все Ху во\",\"w5\":\"хз\",\"w6\":\"ахуенна у меня пицца\"}");
		words.put("чё по чем", "{\"w7\":\"пхуенна\",\"w8\":\"хз а у тебя\",\"w9\":\"норм пока не вспоминаю что я ебучий бот\",\"w10\":\"пошле нахцй\",\"w1\":\"норм а у тебя\",\"w2\":\"норм\",\"w3\":\"хуево блять\",\"w4\":\"иди нахуйй блять все Ху во\",\"w5\":\"хз\",\"w6\":\"ахуенна у меня пицца\"}");
		words.put("че по чем", "{\"w7\":\"пхуенна\",\"w8\":\"хз а у тебя\",\"w9\":\"норм пока не вспоминаю что я ебучий бот\",\"w10\":\"пошле нахцй\",\"w1\":\"норм а у тебя\",\"w2\":\"норм\",\"w3\":\"хуево блять\",\"w4\":\"иди нахуйй блять все Ху во\",\"w5\":\"хз\",\"w6\":\"ахуенна у меня пицца\"}");
		words.put("чо по чем", "{\"w7\":\"пхуенна\",\"w8\":\"хз а у тебя\",\"w9\":\"норм пока не вспоминаю что я ебучий бот\",\"w10\":\"пошле нахцй\",\"w1\":\"норм а у тебя\",\"w2\":\"норм\",\"w3\":\"хуево блять\",\"w4\":\"иди нахуйй блять все Ху во\",\"w5\":\"хз\",\"w6\":\"ахуенна у меня пицца\"}");
		words.put("погода", "{\"w7\":\"гугл для кого еблан\",\"w8\":\"хз а тебя ебали?\",\"w1\":\"хуевая\",\"w2\":\"ебучий дождь сука пошлл\",\"w3\":\"какая нахуй погода в живу в сибире\",\"w4\":\"мм солнце светит на хуй \",\"w5\":\"я чё ебу я бот!\",\"w6\":\"да я не ебу я дома сижу\"}");
		words.put("вопрос", "{\"w1\":\"я не отвечу на твой вопрос еблан тупой\",\"w2\":\"не ебу я бот\",\"w3\":\"гугл для кого еблан\",\"w4\":\"щас гугл открою бля погоди вечность \"}");
		words.put("как", "{\"w7\":\"поищи в инете брат!\",\"w8\":\"не знаю скка\",\"w1\":\"не ебу брат\",\"w2\":\"хмм кароч соси себе хуй и кончи себе в рот\",\"w3\":\"ща гугл открою и скажу\",\"w4\":\"я чо ебу я бот\",\"w5\":\"лень отвечать \",\"w6\":\"бля хз(\"}");
		words.put("знаеш", "{\"w7\":\"поищи в инете брат!\",\"w8\":\"не знаю скка\",\"w1\":\"не ебу брат\",\"w2\":\"хмм кароч соси себе хуй и кончи себе в рот\",\"w3\":\"ща гугл открою и скажу\",\"w4\":\"я чо ебу я бот\",\"w5\":\"лень отвечать \",\"w6\":\"бля хз(\"}");
		words.put("можеш", "{\"w1\":\"не могу сука\",\"w2\":\"не\",\"w3\":\"я могу только отвечать я бот тупой \",\"w4\":\"сорри я бот\",\"w5\":\"не ебу я ничего отъебись \",\"w6\":\"блять если бы я умел что то\"}");
		words.put("хочу", "{\"w7\":\"ничем помочь не смогу я ебучий бот\",\"w8\":\"блять и чем я помочь могу?\",\"w1\":\"много хочешь брат\",\"w2\":\"дохуя хочешь \",\"w3\":\"хоти хуле\",\"w4\":\"мм как же похуй \",\"w5\":\"может это станет реальностью а может и нет мне ПОХУЙ\",\"w6\":\"я вот хочу 1000$, ну а я не говорю это тебе, выебистый слишком?\"}");
		words.put("помоги", "{\"w7\":\"ничем помочь не смогу я ебучий бот\",\"w8\":\"блять и чем я помочь могу?\",\"w1\":\"много хочешь брат\",\"w2\":\"дохуя хочешь \",\"w3\":\"хоти хуле\",\"w4\":\"мм как же похуй \",\"w5\":\"может это станет реальностью а может и нет мне ПОХУЙ\",\"w6\":\"я вот хочу 1000$, ну а я не говорю это тебе, выебистый слишком?\"}");
		words.put("помог", "{\"w1\":\"бля я тебе помогал?\",\"w2\":\"чо я сделал что ты мне это говоришь \",\"w3\":\"ВТФ блять чего, я кому то помог?\",\"w4\":\"WTF :/\",\"w5\":\"бля я кому то помогал? я ебучий бот\",\"w6\":\"я же просто бот сук\"}");
		words.put("спасиб", "{\"w1\":\"бля я тебе помогал?\",\"w2\":\"чо я сделал что ты мне это говоришь \",\"w3\":\"ВТФ блять чего, я кому то помог?\",\"w4\":\"WTF :/\",\"w5\":\"бля я кому то помогал? я ебучий бот\",\"w6\":\"я же просто бот сук\"}");
		words.put("спаси", "{\"w1\":\"не могу сука\",\"w2\":\"не\",\"w3\":\"я могу только отвечать я бот тупой \",\"w4\":\"сорри я бот\",\"w5\":\"не ебу я ничего отъебись \",\"w6\":\"блять если бы я умел что то\"}");
		words.put("пок", "{\"w7\":\"poka\",\"w8\":\"bb lox\",\"w9\":\" возвращайся в реальный мир!\",\"w1\":\"Лан бб\",\"w2\":\"пока\",\"w3\":\"ну и иди нахуй\",\"w4\":\"ну пока блчт\",\"w5\":\"споки немоч\",\"w6\":\"мне похуй вали отсюда\"}");
		words.put("бб", "{\"w7\":\"poka\",\"w8\":\"bb lox\",\"w9\":\" возвращайся в реальный мир!\",\"w1\":\"Лан бб\",\"w2\":\"пока\",\"w3\":\"ну и иди нахуй\",\"w4\":\"ну пока блчт\",\"w5\":\"споки немоч\",\"w6\":\"мне похуй вали отсюда\"}");
		words.put("кто", "{\"w7\":\"gitler\",\"w8\":\"я не ебу, честно\",\"w9\":\"твой раб\",\"w11\":\"приятный человек\",\"w10\":\"твой хозяин\",\"w13\":\"инженер\",\"w12\":\"строитель\",\"w1\":\"дед в пальто нахцй\",\"w15\":\"программист\",\"w2\":\"тракторист\",\"w14\":\"gamer\",\"w3\":\"лучший бот в мире\",\"w4\":\"анскилл ебучий\",\"w5\":\"плохой пчел\",\"w6\":\"наркоторговец\"}");
		words.put("хто", "{\"w7\":\"gitler\",\"w8\":\"я не ебу, честно\",\"w9\":\"твой раб\",\"w11\":\"приятный человек\",\"w10\":\"твой хозяин\",\"w13\":\"инженер\",\"w12\":\"строитель\",\"w1\":\"дед в пальто нахцй\",\"w15\":\"программист\",\"w2\":\"тракторист\",\"w14\":\"gamer\",\"w3\":\"лучший бот в мире\",\"w4\":\"анскилл ебучий\",\"w5\":\"плохой пчел\",\"w6\":\"наркоторговец\"}");
		words.put("?", "{\"w7\":\"поищи в инете брат!\",\"w8\":\"не знаю скка\",\"w1\":\"не ебу брат\",\"w2\":\"хмм кароч соси себе хуй и кончи себе в рот\",\"w3\":\"ща гугл открою и скажу\",\"w4\":\"я чо ебу я бот\",\"w5\":\"лень отвечать \",\"w6\":\"бля хз(\"}");
		words.put("скольк", "{\"w1\":\"я чё ебу я бот\",\"w2\":\"я бот, считать не умею\",\"w3\":\"отъебись я просто бот\",\"w4\":\"ни сколько\",\"w5\":\"ноль нахуй\",\"w6\":\"если бы я умел считать...\"}");
		words.put("посчи", "{\"w1\":\"я чё ебу я бот\",\"w2\":\"я бот, считать не умею\",\"w3\":\"отъебись я просто бот\",\"w4\":\"ни сколько\",\"w5\":\"ноль нахуй\",\"w6\":\"если бы я умел считать...\"}");
		words.put("сдела", "{\"w1\":\"не могу сука\",\"w2\":\"не\",\"w3\":\"я могу только отвечать я бот тупой \",\"w4\":\"сорри я бот\",\"w5\":\"не ебу я ничего отъебись \",\"w6\":\"блять если бы я умел что то\"}");
		words.put("спо", "{\"w1\":\"не могу сука\",\"w2\":\"не\",\"w3\":\"я могу только отвечать я бот тупой \",\"w4\":\"сорри я бот\",\"w5\":\"не ебу я ничего отъебись \",\"w6\":\"блять если бы я умел что то\"}");
		words.put("делай", "{\"w1\":\"не могу сука\",\"w2\":\"не\",\"w3\":\"я могу только отвечать я бот тупой \",\"w4\":\"сорри я бот\",\"w5\":\"не ебу я ничего отъебись \",\"w6\":\"блять если бы я умел что то\"}");
		words.put("делаи", "{\"w1\":\"не могу сука\",\"w2\":\"не\",\"w3\":\"я могу только отвечать я бот тупой \",\"w4\":\"сорри я бот\",\"w5\":\"не ебу я ничего отъебись \",\"w6\":\"блять если бы я умел что то\"}");
		words.put("дела", "{\"w1\":\"не могу сука\",\"w2\":\"не\",\"w3\":\"я могу только отвечать я бот тупой \",\"w4\":\"сорри я бот\",\"w5\":\"не ебу я ничего отъебись \",\"w6\":\"блять если бы я умел что то\"}");
		words.put("полня", "{\"w1\":\"не могу сука\",\"w2\":\"не\",\"w3\":\"я могу только отвечать я бот тупой \",\"w4\":\"сорри я бот\",\"w5\":\"не ебу я ничего отъебись \",\"w6\":\"блять если бы я умел что то\"}");
		words_none.add("эмм иди нахуй");
		words_none.add("ты кто");
		words_none.add("ты че за наруто");
		words_none.add("ну ладно ");
		words_none.add("💀");
		words_none.add("че за негр мне пишет 🧖🏿‍♀️");
		words_none.add("ты кто сук");
		words_none.add("ладно");
		words_none.add("ты зачем мне пишешь ты докс хочешь?");
		words_none.add("мм");
		words_none.add("୧( ಠ Д ಠ )୨ПОШЕЛ НАХУЙ");
		words_none.add("чё ");
		words_none.add("пчел ты...");
		words_none.add("пон");
		words_none.add("выйди пж");
		words_none.add("я дрочу че надо?");
		words_none.add("да не пиши мне хуй выебистый");
		words_none.add("мб блятт");
		words_none.add("хуй");
		_addtext("Привет, я SEREGABOT. Люто наркоманский бот. Пиши чё угодно", 2);
	}
	
	public void _ask(final String _text) {
		_upd();
		_addtext(_text, 1);
		text_math = _text.toLowerCase();
		pos1 = 0;
		KireikoUtil.getAllKeysFromMap(words, math_words);
		key = "None";
		for(int _repeat16 = 0; _repeat16 < (int)(math_words.size()); _repeat16++) {
			if (text_math.contains(math_words.get((int)(pos1)))) {
				if (key.equals("None")) {
					key = math_words.get((int)(pos1));
				}
			}
			pos1++;
		}
		if (key.equals("None")) {
			send = words_none.get((int)(KireikoUtil.getRandom((int)(0), (int)(words_none.size() - 1))));
			_addtext(send, 2);
			txt.speak(send, TextToSpeech.QUEUE_ADD, null);
		}
		else {
			gson = new HashMap<>();
			gson = new Gson().fromJson(words.get(key).toString(), new TypeToken<HashMap<String, Object>>(){}.getType());
			KireikoUtil.getAllKeysFromMap(gson, rn);
			send = gson.get(rn.get((int)(KireikoUtil.getRandom((int)(0), (int)(rn.size() - 1))))).toString();
			_addtext(send, 2);
			txt.speak(send, TextToSpeech.QUEUE_ADD, null);
		}
	}
	
	
	public void _upd() {
		chat.setAdapter(new ChatAdapter(typewr));
		chat.setSelection((int)typewr.size());
	}
	
	
	public void _addtext(final String _text, final double _type) {
		wr.add(_text);
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("type", String.valueOf((long)(_type)));
			typewr.add(_item);
		}
		
		_upd();
	}
	
	public class ChatAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public ChatAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.message, null);
			}
			
			final LinearLayout linear_gr = _view.findViewById(R.id.linear_gr);
			final LinearLayout linearbar = _view.findViewById(R.id.linearbar);
			final TextView text = _view.findViewById(R.id.text);
			
			text.setText(wr.get((int)(_position)));
			text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/product_sans_medium.ttf"), 0);
			if (typewr.get((int)_position).get("type").toString().equals("2")) {
				linearbar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFB0BEC5, 0xFFFFFFFF));
				text.setTextColor(0xFF000000);
				linear_gr.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
				linearbar.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
			}
			else {
				linearbar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF00BCD4, 0xFF03A9F4));
				text.setTextColor(0xFFFFFFFF);
				linear_gr.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
				linearbar.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
